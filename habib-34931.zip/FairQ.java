/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fairq;

import com.opencsv.CSVReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;

/**
 *
 * @author DELL
 */
public class FairQ {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int j=1;
        int k=0;
        String csvFile = "E:\\Study\\semester5\\AdvanceProg\\labs\\Academic _Schedule.csv";
        
        List <String > tasks=new ArrayList();
        HashMap <Object, List<String> > tasksofDay=new HashMap<Object, List<String>>();
        dateKey d;
        
        CSVReader reader = null;
        try {
            reader = new CSVReader(new FileReader(csvFile));
            String[] line;
            String[] task;
            while ((line = reader.readNext()) != null) {
                //System.out.println(line[0]);
                //tasks.add(line[2]);
                tasksofDay.put(new dateKey(line[0],line[1]), tasks);
            }
            //tasks = new ArrayList<String>(new LinkedHashSet<String>(tasks));
            HashMap <Integer,String> priorities=new HashMap<>();
            System.out.println("Priorities of Tasks is as follows:\n");
            
            priorities.put(1, "Maintenance");
            priorities.put(2, "Data Backup");
            priorities.put(3, "New User Registration");
            priorities.put(4, "Course Registration");
            priorities.put(5, "final grading");
            priorities.put(6, "project grading");
            priorities.put(7, "quiz grading");
            priorities.put(8, "assignment grading");
            priorities.put(9, "project upload link creation");
            priorities.put(10, "project submission");
            priorities.put(11, "assignment submission");
            priorities.put(12, "quiz submission");
            priorities.put(13, "lab task upload");
            priorities.put(14, "lecture download");
            priorities.put(15, "lecture preparation");
            priorities.put(16, "ese guideline update");
            priorities.put(17, "1st student feedback");
            priorities.put(18, "2nd student feedback");
            
            System.out.println("Priority Level(1:High, 18:Low)    Tasks");
            while (j<=priorities.size()) {
                //System.out.println(line[0]);
                System.out.println(j+"                             "+priorities.get(j));
                j++;
            }
            
            
            for (Object key: tasksofDay.keySet())
            {
                List <String> val=new ArrayList();
                val=tasksofDay.get(key);
                
                while (k<priorities.size())
                {
                    
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
