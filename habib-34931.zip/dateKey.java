/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fairq;

/**
 *
 * @author DELL
 */
public class dateKey {
    private String date1;
    private String date2;

    public dateKey(String d1,String d2)
    {
        date1=d1;
        date2=d2;
    }
    
    @Override
    public boolean equals(Object obj) {
        if(obj != null && obj instanceof dateKey) {
            dateKey s = (dateKey)obj;
            return date1.equals(s.date1) && date2.equals(s.date2);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (date1 + date2).hashCode();
    }
}
